### additional command buttons <br>
(interface changed)(made for 0.10.0) <br>
<br>
Made for the mobile version and <br>
adds the following buttons: full stop / board ship / land on planet / fire afterburner / fleet: hold position / fleet: gather around me / view player info <br>
adjusts the message box to not overlap <br>
(inspired by theweirednut) <br>